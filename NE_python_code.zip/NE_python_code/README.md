# Code for the Next Energy article (label-free SOH error)

Same code as the Colab notebook `NE_Colab_notebook.ipynb`.

```
pip install numpy pandas scipy scikit-learn matplotlib joblib shap statsmodels jax optax
python run_all.py
```

Put `nasa_cycle_features.csv` (and optionally `GMP.csv`) in `data/` first.

Figures are saved directly under the article numbering, in `figures/` and `figures/NextEnergy/`:

| File | Article figure |
|---|---|
| Figure_1.png | Fig. 1 study design |
| Figure_2.png | Fig. 2 unseen-domain error |
| Figure_3.png | Fig. 3 certificate |
| Figure_4.png | Fig. 4 GMP known truth |
| Figure_5.png | Fig. 5 conformal error bounds |
| Figure_6.png | Fig. 6 reference capacity checks |
| Figure_7.png | Fig. 7 explainability |
| Figure_8.png | Fig. 8 generalizability |
| Figure_S1.png | Fig. S1 offline check placements |
| Figure_S2.png | Fig. S2 label-free warning signals |
| Figure_S3.png | Fig. S3 reliability |
