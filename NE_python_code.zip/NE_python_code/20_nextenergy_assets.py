"""Step 20 - Next Energy submission assets (run last, after 08_workflow.py).
(1) Copies the figures to the numbering of the Next Energy article:
    Fig. 1 study design, Fig. 2 unseen-domain error, Fig. 3 certificate, Fig. 4 simulation with known truth,
    Fig. 5 conformal bounds, Fig. 6 reference checks, Fig. 7 explainability, Fig. 8 generalizability;
    Fig. S1 offline check placements, Fig. S2 label-free warning signals, Fig. S3 reliability.
(2) Draws the graphical abstract (wide format, readable at 13 cm width).
Output: figures/NextEnergy/Figure_1.png ... Figure_8.png, Figure_S1-S3.png, Graphical_abstract.png/.tif"""
import os, shutil, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

FIG, OUT = 'figures', 'outputs'; NE = os.path.join(FIG, 'NextEnergy'); os.makedirs(NE, exist_ok=True)
# Steps 07, 08 and 12 save every figure under its Next Energy number, so the names are copied unchanged.
MAP = {n: n for n in ['Figure_1', 'Figure_2', 'Figure_3', 'Figure_4', 'Figure_5', 'Figure_6', 'Figure_7', 'Figure_8',
                      'Figure_S1', 'Figure_S2', 'Figure_S3']}
for src, dst in MAP.items():
    shutil.copy(os.path.join(FIG, src + '.png'), os.path.join(NE, dst + '.png'))

BLUE, ORANGE, GREEN, GREY, INK, NAVY = '#1f5fbf', '#d9541e', '#138a5e', '#8c8c86', '#111111', '#14325c'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 13, 'axes.spines.top': False, 'axes.spines.right': False,
                     'savefig.dpi': 300})
C = pd.read_csv(f'{OUT}/cells_gbr_self.csv'); T = pd.read_csv(f'{OUT}/tab_checks_causal.csv')
fig = plt.figure(figsize=(16, 6.4))
bg = fig.add_axes([0, 0, 1, 1]); bg.set_xlim(0, 160); bg.set_ylim(0, 64); bg.axis('off')
bg.add_patch(FancyBboxPatch((1, 55.5), 158, 7.5, boxstyle='round,pad=0.2,rounding_size=1.2', fc='#e8eef8', ec=NAVY, lw=1.5))
bg.text(80, 59.2, 'Battery health estimators on a new chemistry or protocol: what can be known without capacity labels?',
        ha='center', va='center', fontsize=16, weight='bold', color=NAVY)
heads = [(3, 'Error depends on the domain', ORANGE), (56, 'Label-free certificate: always valid', BLUE),
         (109, 'A few capacity checks remove bias', GREEN)]
for x, t, c in heads:
    bg.add_patch(FancyBboxPatch((x, 4), 48, 49, boxstyle='round,pad=0.2,rounding_size=1.2', fc='white', ec=c, lw=2.2))
    bg.text(x + 24, 49.5, t, ha='center', va='center', fontsize=14.5, weight='bold', color=c)
# panel 1: per-domain median error
a = fig.add_axes([0.115, 0.2, 0.175, 0.44])
D = C.groupby('dom').rmse.median().sort_values() * 100
a.barh(range(len(D)), D.values, color=ORANGE); a.set_yticks(range(len(D))); a.set_yticklabels([d.replace('Dataset_', 'Set ').replace('Sim_satellite', 'Sat').replace('-', ' ', 1) for d in D.index], fontsize=9)
a.set_xlabel('median RMSE (% SOH)'); bg.text(27, 44.5, '387 cells, 13 unseen domains: 0.4\u20138.4% SOH', ha='center', fontsize=11.5)
# panel 2: certificate vs true error
a = fig.add_axes([0.405, 0.2, 0.22, 0.42])
a.scatter(C.rmse * 100, C.LB * 100, s=10, color=BLUE, alpha=.5); m = C.rmse.max() * 100
a.plot([0.1, m], [0.1, m], color=INK, ls='--', lw=1.5); a.set_xscale('log'); a.set_yscale('log')
a.set_xlim(0.2, m * 1.3); a.set_ylim(0.005, m * 1.3)
a.set_xlabel('true error (% SOH)'); a.set_ylabel('certificate LB (% SOH)')
a.set_title('LB ≤ error in all 4,257 cell–estimator pairs (main\nmodel shown), yet it sees only 0.4–8.9% of the error', fontsize=11, loc='left')
# panel 3: online error vs number of checks
a = fig.add_axes([0.745, 0.2, 0.215, 0.42]); base = T[T.K == 0]['median'].values[0] * 100
d = T[T.schedule == 'fixed']; a.plot([0] + list(d.K), [base] + list(d['median'] * 100), color=GREEN, lw=3, marker='o')
a.set_xlabel('capacity checks per cell'); a.set_ylabel('online median RMSE (% SOH)'); a.set_xticks(range(6))
a.set_title(f'{base:.2f}% → {d[d.K == 3]["median"].values[0] * 100:.2f}% SOH with 3 checks', fontsize=11.5, loc='left')
fig.savefig(f'{NE}/Graphical_abstract.png', facecolor='white')
fig.savefig(f'{NE}/Graphical_abstract.tif', facecolor='white', pil_kwargs={'compression': 'tiff_lzw'})
print('Next Energy figures and graphical abstract written to', NE)
