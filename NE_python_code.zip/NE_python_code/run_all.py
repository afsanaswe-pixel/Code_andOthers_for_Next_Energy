"""Run the whole pipeline (same steps and order as the Colab notebook).
Before running: put nasa_cycle_features.csv (and optionally GMP.csv) in data/.
The public XJTU, TJU, HUST and MIT data are downloaded automatically (git clone of PINN4SOH, commit cc3cc50).
Set MONO_QUICK=1 for a fast smoke test. Full run: about 75 minutes on 2 CPU cores.
Article figures end up in figures/NextEnergy with the same names as the LaTeX figs/ folder."""
import os, subprocess, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
steps = ["01_lodo", "14_strong all", "02_certificate", "03_signals", "04_meta", "05_checks", "06_controls", "09_reliability",
         "10_explain", "11_generalize", "15_stats", "16_checks_causal", "17_conformal", "18_xai_error", "19_diag",
         "07_figures", "12_figures_trends", "13_tables", "08_workflow", "20_nextenergy_assets"]
for s in steps:
    print('===', s, flush=True)
    a = s.split()
    r = subprocess.run([sys.executable, '-u', a[0] + '.py'] + a[1:], capture_output=True, text=True)
    print('\n'.join(l for l in r.stdout.splitlines() if 'arning' not in l)[-3000:])
    if r.returncode:
        print(r.stderr[-3000:]); sys.exit(r.returncode)
print('done')
